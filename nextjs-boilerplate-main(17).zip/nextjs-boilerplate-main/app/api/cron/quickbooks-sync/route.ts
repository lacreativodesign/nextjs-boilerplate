import { NextRequest, NextResponse } from "next/server";
import { adminDb } from "@/lib/firebaseAdmin";
import { runQuickBooksSync } from "@/lib/integrations/quickbooks";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  try {
    const secret = process.env.CRON_SECRET;
    if (!secret || secret === "change-me-in-production") {
      return NextResponse.json({ ok: false, error: "Cron secret is not configured securely." }, { status: 500 });
    }

    if (request.headers.get("authorization") !== `Bearer ${secret}`) {
      return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
    }

    const integrations = await adminDb
      .collectionGroup("integrations")
      .where("connected", "==", true)
      .where("settings.scheduleDaily", "==", true)
      .get();

    const results: Array<{ tenantId: string; ok: boolean; error?: string }> = [];

    for (const doc of integrations.docs) {
      if (doc.id !== "quickbooks") continue;
      const tenantRef = doc.ref.parent.parent;
      if (!tenantRef) continue;
      const tenantId = tenantRef.id;
      try {
        await runQuickBooksSync({ tenantId, userUid: "system:cron" });
        results.push({ tenantId, ok: true });
      } catch (error: any) {
        results.push({ tenantId, ok: false, error: error?.message || "Sync failed" });
      }
    }

    return NextResponse.json({ ok: true, processed: results.length, results });
  } catch (error: any) {
    console.error("cron/quickbooks-sync error", error);
    return NextResponse.json({ ok: false, error: error?.message || "QuickBooks cron sync failed." }, { status: 500 });
  }
}
