import { NextResponse } from "next/server";
import { adminDb } from "@/lib/firebaseAdmin";
import { requireAdmin } from "../../_utils";
import { normalizeInvoiceStatus } from "@/lib/finance/status";
import { normalizeTenantId } from "@/lib/tenant";
import { queryWithTenant } from "@/lib/tenant/query";

export const dynamic = "force-dynamic";

function toCSV(rows: string[][]) {
  return rows.map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(",")).join("\n");
}

export async function GET() {
  try {
    const auth = await requireAdmin();
    if (!auth.ok) {
      return NextResponse.json({ ok: false, error: auth.error }, { status: auth.status });
    }

    const tenantId = normalizeTenantId(auth.user.tenantId);
    const docs = await queryWithTenant(
      adminDb.collection("invoices").where("isDeleted", "==", false).limit(500),
      tenantId
    );
    const totals = new Map<string, number>();

    docs.forEach((doc) => {
      const data = doc.data() || {};
      if (normalizeInvoiceStatus(data.status) !== "paid") return;
      const client = String(data.clientName || "Unknown");
      totals.set(client, (totals.get(client) || 0) + Number(data.amountTotalUsd || 0));
    });

    const rows = [["Client", "Revenue USD"]];
    Array.from(totals.entries()).forEach(([client, total]) => {
      rows.push([client, total.toFixed(2)]);
    });

    const csv = toCSV(rows);
    return new NextResponse(csv, {
      headers: {
        "Content-Type": "text/csv",
        "Content-Disposition": "attachment; filename=finance-revenue-by-client.csv",
      },
    });
  } catch (err: any) {
    console.error("finance/reports revenue-by-client error:", err);
    return NextResponse.json({ ok: false, error: "Unable to export report." }, { status: 500 });
  }
}
