import { NextResponse } from "next/server";
import { adminDb } from "@/lib/firebaseAdmin";
import { createSalesEvent, parseNumber, parseString, requireAdmin, serverTimestamp } from "../../_utils";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const auth = await requireAdmin();
    if (!auth.ok) {
      return NextResponse.json({ ok: false, error: auth.error }, { status: auth.status });
    }

    const payload = await req.json();
    const id = parseString(payload.id, "");
    if (!id) {
      return NextResponse.json({ ok: false, error: "Missing campaign id." }, { status: 400 });
    }

    const updates: Record<string, any> = {
      updatedAt: serverTimestamp(),
    };

    if (payload.name !== undefined) updates.name = parseString(payload.name, "");
    if (payload.channel !== undefined) updates.channel = parseString(payload.channel, "");
    if (payload.leadsCount !== undefined) updates.leadsCount = parseNumber(payload.leadsCount, 0);
    if (payload.dealsCount !== undefined) updates.dealsCount = parseNumber(payload.dealsCount, 0);
    if (payload.revenueUsd !== undefined) updates.revenueUsd = parseNumber(payload.revenueUsd, 0);
    if (updates.leadsCount !== undefined || updates.dealsCount !== undefined) {
      const leads = updates.leadsCount ?? payload.leadsCount ?? 0;
      const deals = updates.dealsCount ?? payload.dealsCount ?? 0;
      updates.conversionRate = leads ? (deals / leads) * 100 : 0;
    }

    await adminDb.collection("campaigns").doc(id).set(updates, { merge: true });

    await createSalesEvent({
      type: "campaign_updated",
      title: "Campaign updated",
      description: `Campaign ${id} updated`,
      entityType: "campaign",
      entityId: id,
      createdByUid: auth.user.uid,
      createdByName: auth.user.name || auth.user.fullName || "",
      tenantId: auth.user.tenantId,
    });

    return NextResponse.json({ ok: true });
  } catch (err: any) {
    console.error("sales campaigns update error:", err);
    return NextResponse.json({ ok: false, error: "Unable to update campaign." }, { status: 500 });
  }
}
